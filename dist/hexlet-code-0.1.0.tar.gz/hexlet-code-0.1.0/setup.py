# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff',
 'gendiff.engine',
 'gendiff.formaters',
 'gendiff.scripts',
 'gendiff.tests']

package_data = \
{'': ['*'],
 'gendiff.tests': ['fixtures/correct_answers/*',
                   'fixtures/json/*',
                   'fixtures/yaml/*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'flake8>=4.0.1,<5.0.0',
 'pytest-cov>=3.0.0,<4.0.0',
 'pytest>=7.1.2,<8.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'NikolyKa',
    'author_email': 'karabakin.kolia@mail.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
