#!/usr/bin/env python
from gendiff.mainstr import parser


def main():
    parser()


if __name__ == '__main__':
    main()
