import json


def jsons(data):
    return json.dumps(data)